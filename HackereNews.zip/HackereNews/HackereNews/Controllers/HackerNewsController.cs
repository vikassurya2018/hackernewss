﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using HackereNews.Models;

[Route("api/[controller]")]
[ApiController]
public class HackerNewsController : ControllerBase
{
    private readonly IHttpClientFactory _httpClientFactory;

    public HackerNewsController(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    [HttpGet("best-stories")]
    public async Task<ActionResult<IEnumerable<HackerNewsStory>>> GetBestStories(int n)
    {
        try
        {
            var httpClient = _httpClientFactory.CreateClient();
            var bestStoryIdsResponse = await httpClient.GetStringAsync("https://hacker-news.firebaseio.com/v0/beststories.json");
            var bestStoryIds = JsonSerializer.Deserialize<List<int>>(bestStoryIdsResponse);

            // Fetch details for the top N stories
            var topNStories = new List<HackerNewsStory>();
            for (int i = 0; i < n && i < bestStoryIds.Count; i++)
            {
                var storyId = bestStoryIds[i];
                var storyResponse = await httpClient.GetStringAsync($"https://hacker-news.firebaseio.com/v0/item/{storyId}.json");
                var story = JsonSerializer.Deserialize<HackerNewsStory>(storyResponse);
                topNStories.Add(story);
            }

            // Sort stories by score in descending order
            topNStories.Sort((s1, s2) => s2.Score.CompareTo(s1.Score));

            return Ok(topNStories);
        }
        catch (Exception ex)
        {
            // Handle exceptions and return an error response
            return StatusCode(500, "Internal Server Error");
        }
    }
}